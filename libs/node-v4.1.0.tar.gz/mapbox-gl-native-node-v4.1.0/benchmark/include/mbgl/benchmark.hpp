#pragma once

namespace mbgl {

int runBenchmark(int argc, char* argv[]);

} // namespace mbgl
