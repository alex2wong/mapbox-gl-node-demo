#include <mbgl/benchmark.hpp>

int main(int argc, char* argv[]) {
    return mbgl::runBenchmark(argc, argv);
}
