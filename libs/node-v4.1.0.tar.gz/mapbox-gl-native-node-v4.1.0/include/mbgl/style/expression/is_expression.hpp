#pragma once

#include <mbgl/style/expression/expression.hpp>

namespace mbgl {
namespace style {
namespace expression {

bool isExpression(const conversion::Convertible& value);

} // namespace expression
} // namespace style
} // namespace mbgl
