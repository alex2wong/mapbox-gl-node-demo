package com.mapbox.mapboxsdk.constants;

public class AppConstant {

  public static final int STYLE_VERSION = 9;
}
