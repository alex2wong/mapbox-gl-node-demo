/**
 * Contains the Mapbox Maps Android Style Layer API classes.
 */
package com.mapbox.mapboxsdk.style.layers;
