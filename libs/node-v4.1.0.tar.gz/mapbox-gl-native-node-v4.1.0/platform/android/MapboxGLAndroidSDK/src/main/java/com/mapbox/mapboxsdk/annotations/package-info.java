/**
 * Contains the Mapbox Maps Android Annotation API classes.
 */
package com.mapbox.mapboxsdk.annotations;
