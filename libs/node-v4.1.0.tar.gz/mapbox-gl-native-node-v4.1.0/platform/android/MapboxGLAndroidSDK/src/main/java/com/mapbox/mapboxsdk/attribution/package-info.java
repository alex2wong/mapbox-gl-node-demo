/**
 * Contains the Mapbox Maps Android Attribution API classes.
 */
package com.mapbox.mapboxsdk.attribution;
