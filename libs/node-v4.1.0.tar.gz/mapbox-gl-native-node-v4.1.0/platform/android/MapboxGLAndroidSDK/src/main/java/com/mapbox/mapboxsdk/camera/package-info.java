/**
 * Contains the Mapbox Maps Android Camera API classes.
 */
package com.mapbox.mapboxsdk.camera;
