/**
 * Do not use this package. Internal use only.
 */
package com.mapbox.mapboxsdk.http;
