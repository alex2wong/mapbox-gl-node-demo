/**
 * Contains the Mapbox Maps Android Text API classes.
 */
package com.mapbox.mapboxsdk.text;
