package com.mapbox.mapboxsdk.location;

interface OnCameraMoveInvalidateListener {

  void onInvalidateCameraMove();

}
