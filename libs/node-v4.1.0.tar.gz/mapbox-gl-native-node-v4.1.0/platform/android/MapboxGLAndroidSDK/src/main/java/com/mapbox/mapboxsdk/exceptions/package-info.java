/**
 * Contains the Mapbox Maps Android Exception API classes.
 */
package com.mapbox.mapboxsdk.exceptions;
