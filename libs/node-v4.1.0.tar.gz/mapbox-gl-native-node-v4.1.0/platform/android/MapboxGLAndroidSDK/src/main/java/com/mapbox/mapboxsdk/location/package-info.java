/**
 * Contains the Mapbox Location layer plugin.
 */
package com.mapbox.mapboxsdk.location;