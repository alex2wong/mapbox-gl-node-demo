/**
 * Contains the Mapbox Maps Android Geometry API classes.
 */
package com.mapbox.mapboxsdk.geometry;
