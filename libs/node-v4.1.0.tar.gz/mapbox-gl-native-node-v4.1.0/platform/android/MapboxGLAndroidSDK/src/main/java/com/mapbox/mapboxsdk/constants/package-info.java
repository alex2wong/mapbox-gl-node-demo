/**
 * Contains the Mapbox Maps Android Constant API classes.
 */
package com.mapbox.mapboxsdk.constants;
